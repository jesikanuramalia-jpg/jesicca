function openTab(event, tabName) {
    // 1. Ambil semua elemen dengan class content-section dan sembunyikan
    const content = document.getElementsByClassName("content-section");
    for (let i = 0; i < content.length; i++) {
        content[i].classList.remove("active");
    }

    // 2. Ambil semua tombol tab dan hapus class active-nya
    const buttons = document.getElementsByClassName("btn-tab");
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove("active");
    }

    // 3. Tampilkan section yang dipilih
    document.getElementById(tabName).classList.add("active");

    // 4. Tambahkan class active ke tombol yang baru saja diklik
    event.currentTarget.classList.add("active");
}

function searchProduct() {
    let input = document.getElementById('searchInput').value.toLowerCase();
    let cards = document.getElementsByClassName('product-card');

    for (let i = 0; i < cards.length; i++) {
        let title = cards[i].getElementsByTagName('b')[0].innerText.toLowerCase();
        if (title.includes(input)) {
            cards[i].style.display = "";
        } else {
            cards[i].style.display = "none";
        }
    }
}

function toggleDarkMode() {
    const body = document.body;
    const icon = document.getElementById('dark-icon');
    const text = document.getElementById('dark-text');
    
    body.classList.toggle('dark-mode');
    
    if (body.classList.contains('dark-mode')) {
        icon.innerHTML = "☀️";
        text.innerHTML = "Mode bright";
    } else {
        icon.innerHTML = "🌙";
        text.innerHTML = "Mode dark";
    }
}
window.addEventListener("load", function() {
    const loader = document.getElementById("loader-wrapper");
    setTimeout(() => {
        loader.style.opacity = "0";
        setTimeout(() => {
            loader.style.display = "none";
        }, 500);
    }, 1500); // 1.5 detik aja biar gak kelamaan
});
function searchProduct() {
    // 1. Ambil teks yang diketik user
    let input = document.getElementById('searchInput').value.toLowerCase();
    
    // 2. Ambil semua kartu produk
    let cards = document.getElementsByClassName('product-card');
    
    // 3. Looping/Cek satu-satu kartu produknya
    for (let i = 0; i < cards.length; i++) {
        // Ambil teks nama produk (biasanya di dalam tag <p> atau <b>)
        let productName = cards[i].innerText.toLowerCase();
        
        // 4. Kalau nama produk cocok sama ketikan, tampilkan. Kalau gak cocok, sembunyikan.
        if (productName.includes(input)) {
            cards[i].style.display = ""; // Munculin
        } else {
            cards[i].style.display = "none"; // Sembunyiin
        }
    }
}
function searchProduct() {
    // 1. Ambil input dan ubah jadi huruf kecil semua
    let input = document.getElementById('searchInput').value.toLowerCase();
    
    // 2. Ambil semua elemen dengan class product-card
    let cards = document.querySelectorAll('.product-card');
    
    // 3. Putar semua kartu satu-satu
    cards.forEach(card => {
        // Ambil semua teks yang ada di dalam kartu itu
        let text = card.textContent.toLowerCase();
        
        // 4. Cek apakah kata yang dicari ada di dalam teks kartu
        if (text.includes(input)) {
            card.style.display = ""; // Tampilkan kalau cocok
        } else {
            card.style.display = "none"; // Sembunyikan kalau gak ada
        }
    });
}
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
    let btn = document.getElementById("backToTop");
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
}
function topFunction() {
    window.scrollTo({top: 0, behavior: 'smooth'});
}

